<?php

return [
    'module' => [
        'class' => 'application.modules.delivery.DeliveryModule',
    ],
    'import' => [
        'application.modules.delivery.models.*',
    ],
];
