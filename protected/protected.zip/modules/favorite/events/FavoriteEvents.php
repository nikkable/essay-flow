<?php

/**
 * Class FavoriteEvents
 */
class FavoriteEvents
{
    /**
     *
     */
    const ADD_TO_FAVORITE = 'favorite.add.success';

    /**
     *
     */
    const REMOVE_FROM_FAVORITE = 'favorite.remove.success';
}