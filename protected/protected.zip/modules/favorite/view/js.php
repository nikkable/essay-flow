<script type="text/javascript">
    var yupeStoreAddFavoriteUrl = '<?= Yii::app()->createAbsoluteUrl('/favorite/favorite/add'); ?>';
    var yupeStoreRemoveFavoriteUrl = '<?= Yii::app()->createAbsoluteUrl('/favorite/favorite/remove'); ?>'
</script>