<?php

/**
 * Interface ICommentAllowed
 */
interface ICommentAllowed
{
    /**
     * @return mixed
     */
    public function isCommentAllowed();
}