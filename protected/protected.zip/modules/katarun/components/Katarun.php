<?php

require_once '../protected/modules/katarun/vendor/autoload.php';

/**
 * Class for working with Katarun REST
 *
 * @package  yupe.modules.katarun.components
 * @author   Nikkable
 * @license
 **/
class Katarun
{
    // Payment key
    private $key;

    private $brand_id;
    private $api_key;
    private $endpoint;
    private $return_url;
    private $fail_url;

    public function __construct(Payment $payment)
    {
        $settings = $payment->getPaymentSystemSettings();

        $this->brand_id = $settings['brand_id'];
        $this->api_key = $settings['api_key'];
        $this->endpoint = $settings['endpoint'];
        $this->return_url = $settings['return_url'];
        $this->fail_url = $settings['fail_url'];
    }

    /**
     * Starts a payment session and returns its ID
     *
     * @param Order $order
     * @return string|bool
     */
    public function getFormUrl(Order $order)
    {

        $katarun = new Katarun\KatarunApi($this->brand_id,  $this->api_key, $this->endpoint);
        $client = new \Katarun\Model\ClientDetails();
        $client->email = $order->email;
        $purchase = new \Katarun\Model\Purchase();
        $purchase->client = $client;

        $details = new \Katarun\Model\PurchaseDetails();
        $product = new \Katarun\Model\Product();
        $product->name = 'Test';
        $product->quantity = 1;
        $product->price = $order->getTotalPriceWithDelivery() * 100;

        $details->products = [$product];
        $purchase->purchase = $details;
        $purchase->brand_id = $this->brand_id;
        $purchase->success_redirect = $this->return_url . '?orderId=' . $order->id;
        $purchase->failure_redirect = $this->fail_url . '?orderId=' . $order->id;

        $result = $katarun->createPurchase($purchase);

        if ($result && $result->id) {
            $order->katarun_id = $result->id;
            $order->save();
        }

        if ($result && $result->checkout_url) {
            return $result->checkout_url;
        }

//        $data = [
//            'userName' => $this->userName,
//            'password' => $this->password,
//            'returnUrl' => $this->returnUrl,
//            'failUrl' => $this->failUrl,
//            'sessionTimeoutSecs' => $this->sessionTimeoutSecs,
//            'language' => $this->language,
//            'jsonParams' => json_encode(['email' => $order->email]),
//            'orderNumber' => $order->id,
//            'amount' => $order->getTotalPriceWithDelivery() * 100,
//            'description' =>  Yii::t('KatarunModule.katarun', 'Payment order #{n} on "{site}" website', [
//                '{n}' => $order->id,
//                '{site}' => Yii::app()->getModule('yupe')->siteName
//            ])
//        ];

        return '';
    }

    /**
     * Gets the status of the current payment
     *
     * @param CHttpRequest $request
     * @param Order $order
     * @return string|bool
     */
    public function getPaymentStatus(CHttpRequest $request, Order $order)
    {
        $katarun = new \Katarun\KatarunApi($this->brand_id,  $this->api_key, $this->endpoint);
        $purchase = $katarun->getPurchase($order->katarun_id);

        if($purchase && $purchase->status === 'paid') {
            return true;
        }

        return false;
    }
}
