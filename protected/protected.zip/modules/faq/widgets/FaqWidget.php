<?php
Yii::import('application.modules.faq.models.*');

class FaqWidget extends yupe\widgets\YWidget
{
    public $view = 'faq';

    public function run()
    {
        $criteria = new CDbCriteria();
        $criteria->limit = (int)$this->limit;
        $criteria->order = 'date DESC';


		$model = Faq::model()->findAll();

        $this->render($this->view, ['model' => $model]);

    }
}