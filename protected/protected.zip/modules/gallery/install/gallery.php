<?php
/**
 * Файл конфигурации модуля
 *
 * @category YupeMigration
 * @package  yupe.modules.gallery.install
 * @author   YupeTeam <support@yupe.ru>
 * @license  BSD https://raw.github.com/yupe/yupe/master/LICENSE
 * @link     https://yupe.ru
 **/
return [
    'module' => [
        'class' => 'application.modules.gallery.GalleryModule',
    ],
    'import' => [],
    'component' => [],
    'rules' => [
        '/albums' => '/gallery/gallery/index',
        '/albums/<id:\d+>' => '/gallery/gallery/view',
        '/albums/images/<id:\d+>' => '/gallery/gallery/image',
        '/albums/categories' => '/gallery/galleryCategory/index',
        '/albums/<slug>' => '/gallery/galleryCategory/view',
    ],
];
