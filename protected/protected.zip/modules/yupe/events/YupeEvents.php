<?php
namespace yupe\events;

class YupeEvents
{
    const BEFORE_BACKEND_CONTROLLER_ACTION = 'yupe.before.backend.controller.action';

    const BACKEND_CONTROLLER_INIT = 'yupe.backend.controller.init';

    const BEFORE_FRONT_CONTROLLER_INIT = 'yupe.before.front.controller.init';
}
