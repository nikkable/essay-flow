<?php

class {ClassName} extends yupe\components\DbMigration
{
	public function safeUp()
	{

	}

	public function safeDown()
	{

	}
}