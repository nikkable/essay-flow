<?php
class CategoryEvents
{
    const CATEGORY_AFTER_SAVE = 'category.after.save';
    const CATEGORY_AFTER_DELETE = 'category.after.delete';
}