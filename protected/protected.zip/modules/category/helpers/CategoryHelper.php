<?php
class CategoryHelper
{
    const CATEGORY_CACHE_DESCENDANTS = 'Category::CategoryDescendants::';
    const CATEGORY_CACHE_ALIAS = 'Category::CategoryAlias::';
    const CATEGORY_CACHE_TAG = 'yupe::category';
}