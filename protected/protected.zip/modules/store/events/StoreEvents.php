<?php
class StoreEvents
{
    const CATEGORY_AFTER_SAVE = 'category.after.save';
    const CATEGORY_AFTER_DELETE = 'category.after.delete';
    const PRODUCT_OPEN = 'store.product.open';
}