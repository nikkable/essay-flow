<?php

return [
    'Store' => '',
    'Orders' => '',
    'New' => '',
    'Total' => '',
    'Order #' => '',
];
