<?php

Yii::import('application.modules.rackcalc.models.Periods');
Yii::import('application.modules.rackcalc.models.Subjects');
Yii::import('application.modules.rackcalc.models.Words');

/**
 * Class OrderController
 */
class OrderController extends \yupe\components\controllers\FrontController
{
    /**
     * @param null $url
     * @throws CHttpException
     */
    public function actionView($url = null)
    {
        if (!Yii::app()->getModule('order')->showOrder && !Yii::app()->getUser()->isAuthenticated()) {
            throw new CHttpException(404, Yii::t('OrderModule.order', 'Page not found!'));
        }

        $model = Order::model()->findByUrl($url);

        if ($model === null) {
            throw new CHttpException(404, Yii::t('OrderModule.order', 'Page not found!'));
        }

        $this->render('view', ['model' => $model]);
    }

    /**
     *
     */
    public function actionCreate()
    {
        $model = new Order(Order::SCENARIO_USER);

        if (Yii::app()->getRequest()->getIsPostRequest() && Yii::app()->getRequest()->getPost('Order')) {

            $order = Yii::app()->getRequest()->getPost('Order');

            $rackcalcPeriod = Periods::model()->findByPk($order['rackcalcPeriod']);
            $rackcalcSubject = Subjects::model()->findByPk($order['rackcalcSubject']);
            $rackcalcWord = $order['rackcalcWord'] + 1;
            $rackcalcPage = Yii::app()->getModule('rackcalc')->pricePage;

            $totalPriceSubject = $rackcalcPage + ($rackcalcPage * ($rackcalcSubject->cost / 100));
            $totalPricePeriod = $totalPriceSubject + ($totalPriceSubject * ($rackcalcPeriod->cost / 100));
            $totalPrice = $rackcalcWord * $totalPricePeriod;

            $product = new Product;
            $product->name = 'Esse order ' . $rackcalcPeriod->name . ' ' . $rackcalcSubject->name;
            $product->price = $totalPrice;
            $product->slug = uniqid();
            $product->short_description = 'Esse order ' . $rackcalcPeriod->name . ' ' . $rackcalcSubject->name;
            $product->description       = '
                <div class="order-list-har">
                    <div class="order-list-har-label">Deadline:</div>
                    <div class="order-list-har-value">' . $rackcalcPeriod->name . '</div>
                </div>
                <div class="order-list-har">
                    <div class="order-list-har-label">Subject:</div>
                    <div class="order-list-har-value">' . $rackcalcSubject->name . '</div>
                </div>
                <div class="order-list-har">
                    <div class="order-list-har-label">Words:</div>
                    <div class="order-list-har-value">' . $rackcalcWord . '</div>
                </div>
            ';
            $product->create_time = date('Y-d-m h:i:s');
            $product->update_time = date('Y-d-m h:i:s');

            $product->save();

//            echo "<pre>";
//            print_r($product->attributes);
//            die;

            $products = [
                [
                    'product_id' => $product->id,
                    'quantity' => 1
                ]
            ];

            $coupons = isset($order['couponCodes']) ? $order['couponCodes'] : [];

            if ($model->store($order, $products, Yii::app()->getUser()->getId(), (int)Yii::app()->getModule('order')->defaultStatus)) {

                Yii::app()->cart->clear();

                if (!empty($coupons)) {
                    $model->applyCoupons($coupons);
                }

                Yii::app()->getUser()->setFlash(
                    yupe\widgets\YFlashMessages::SUCCESS_MESSAGE,
                    Yii::t('OrderModule.order', 'The order created')
                );

                Yii::app()->eventManager->fire(OrderEvents::CREATED_HTTP, new OrderEvent($model));

                if (Yii::app()->getModule('order')->showOrder) {
                    $this->redirect(['/order/order/view', 'url' => $model->url]);
                }

                $this->redirect(['/store/product/index']);

            } else {
                $error = CHtml::errorSummary($model);
                Yii::app()->getUser()->setFlash(
                    yupe\widgets\YFlashMessages::ERROR_MESSAGE,
                    $error ?: Yii::t('OrderModule.order', 'Order error')
                );

                $this->redirect(['/cart/cart/index']);
            }
        }

        $this->redirect(Yii::app()->getUser()->getReturnUrl());
    }

    /**
     * @throws CHttpException
     */
    public function actionCheck()
    {
        if (!Yii::app()->getModule('order')->enableCheck) {
            throw new CHttpException(404);
        }

        $form = new CheckOrderForm();

        $order = null;

        if (Yii::app()->getRequest()->getIsPostRequest()) {

            $form->setAttributes(
                Yii::app()->getRequest()->getPost('CheckOrderForm')
            );

            if ($form->validate()) {
                $order = Order::model()->findByNumber($form->number);
            }
        }

        $this->render('check', ['model' => $form, 'order' => $order]);
    }
}
