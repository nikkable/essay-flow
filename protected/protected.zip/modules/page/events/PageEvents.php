<?php

/**
 * Class PageEvents
 */
class PageEvents
{
    /**
     *
     */
    const PAGE_AFTER_SAVE = 'page.after.save';
}