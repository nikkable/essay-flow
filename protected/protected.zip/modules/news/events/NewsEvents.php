<?php
class NewsEvents
{
    const NEWS_AFTER_SAVE = 'news.after.save';
    const NEWS_AFTER_DELETE = 'news.after.delete';
}