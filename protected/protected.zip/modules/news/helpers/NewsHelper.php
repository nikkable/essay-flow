<?php

/**
 * Class NewsHelper
 */
class NewsHelper
{
    const CACHE_NEWS_LIST = 'News::NewsList';
    const CACHE_NEWS_TAG = 'yupe::news';
}