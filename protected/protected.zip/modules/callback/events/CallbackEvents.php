<?php

/**
 * Class CallbackEvents
 */
class CallbackEvents
{
    const ADD = 'callback.add';
}
