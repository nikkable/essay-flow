<?php

return [
    'Enter' => 'Введіть',
    'Error while saving record!' => 'Помилка під час збереження запису',
    'Model {class} does not have attribute "{attr}"' => 'Модель {class} не має атрибуту "{attr}"',
    'Model {class} not found by primary key "{pk}"' => 'Модель {class}, що має первинний ключ "{pk}" не знайдено ',
    'Model {class} rules do not allow to update attribute "{attr}"' => 'Правило моделі {class} не дозволяють змінювати вказаний атрибут "{attr}"',
    'Property "attribute" should be defined.' => 'Властивість "attribute" повинно бути вказано',
    'Property "primaryKey" should be defined.' => 'Властивість "primaryKey" повинно бути вказано',
    'You should provide modelClass in constructor of EditableSaver.' => 'Ви мусите вказати modelClass в конструкторі EditableSaver.',
];
